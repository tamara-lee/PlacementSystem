-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: prismadb
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES ('173e8ac9-1085-482a-bf6a-7785eafde680','daf2f82793a614febd8f70fcaf609c9ac81f1ecbfc2552c3fff1e4db7d1b3db8','2022-04-13 08:27:18.047','20220320125356_added_account_id_index_in_student_table',NULL,NULL,'2022-04-13 08:27:17.972',1),('87d3a9ce-112e-4f1b-bb54-b419a10f681b','b5f383ac1ade9efb38e3c6cbaf201da2a1c11c1210547161920350f0789d2a9b','2022-04-13 08:27:16.940','20220211033636_migration_one',NULL,NULL,'2022-04-13 08:27:16.780',1),('9a4c3994-e517-4d6e-8f66-b082bc525451','79e4cf67056606edd2283c7528c2f97bf4e309a58406006d56b082306e046adc','2022-04-13 08:27:17.792','20220309141452_try',NULL,NULL,'2022-04-13 08:27:16.945',1),('c329bc92-b99e-4618-b06c-0b3a3760ebc2','495fabb2c8537971752af99e62caa1b26f2136ca423d8546cc3d502e8f083633','2022-04-13 08:27:17.968','20220320074040_one_to_one_user_and_student',NULL,NULL,'2022-04-13 08:27:17.797',1),('e6d7f569-7410-48cb-95b1-040d55579dd1','74e9621194fb1e6d39ae75dbba92c11f9e690ef3fc519e19c2b3939fa29e5aab','2022-04-13 08:27:18.741','20220413082056_try',NULL,NULL,'2022-04-13 08:27:18.052',1),('f88665e0-f23d-4996-866b-b9ab75632f2d','11a1b8f0dfe4cb6281dcb7435a638daeccec78beb4cee67791329bdb87663a68','2022-04-16 13:53:09.886','20220416135309_removed_extra_tables',NULL,NULL,'2022-04-16 13:53:09.847',1);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-18 14:47:31
